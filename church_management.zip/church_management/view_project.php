<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isset($_GET['id'])) {
    redirect('index.php');
}

$id = intval($_GET['id']);

$sql = "SELECT projects.*, admins.username as admin_name FROM projects 
        LEFT JOIN admins ON projects.admin_id = admins.id 
        WHERE projects.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    redirect('index.php');
}

$project = $result->fetch_assoc();
$stmt->close();

$progress = ($project['current_amount'] / $project['target_amount']) * 100;
?>

<?php include 'includes/header.php'; ?>

<main class="main-content">
    <section class="project-detail">
        <div class="container">
            <div class="project-content">
                <div class="project-header">
                    <h1 class="project-title"><?php echo htmlspecialchars($project['title']); ?></h1>
                    <span class="project-status <?php echo strtolower($project['status']); ?>">
                        <?php echo $project['status']; ?>
                    </span>
                </div>
                
                <div class="project-meta">
                    <div class="meta-item">
                        <span class="meta-label">Start Date:</span>
                        <span class="meta-value"><?php echo date('M j, Y', strtotime($project['start_date'])); ?></span>
                    </div>
                    <?php if ($project['end_date']): ?>
                    <div class="meta-item">
                        <span class="meta-label">End Date:</span>
                        <span class="meta-value"><?php echo date('M j, Y', strtotime($project['end_date'])); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="meta-item">
                        <span class="meta-label">Posted by:</span>
                        <span class="meta-value"><?php echo htmlspecialchars($project['admin_name']); ?></span>
                    </div>
                </div>
                
                <div class="project-progress">
                    <div class="progress-info">
                        <div class="progress-amount">
                            <span>Raised: <?php echo number_format($project['current_amount'], 2); ?> TZS</span>
                            <span>Target: <?php echo number_format($project['target_amount'], 2); ?> TZS</span>
                        </div>
                        <div class="progress-percent">
                            <?php echo number_format($progress, 2); ?>%
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress" style="width: <?php echo $progress; ?>%"></div>
                    </div>
                </div>
                
                <div class="project-description">
                    <h3>Project Description</h3>
                    <?php echo nl2br(htmlspecialchars($project['description'])); ?>
                </div>
                
                <a href="index.php#projects" class="btn btn-primary">Back to Projects</a>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
