<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isset($_GET['id'])) {
    redirect('index.php');
}

$id = intval($_GET['id']);

$sql = "SELECT news.*, admins.username as admin_name FROM news 
        LEFT JOIN admins ON news.admin_id = admins.id 
        WHERE news.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    redirect('index.php');
}

$news = $result->fetch_assoc();
$stmt->close();
?>

<?php include 'includes/header.php'; ?>

<main class="main-content">
    <section class="news-detail">
        <div class="container">
            <div class="news-content">
                <div class="news-meta">
                    <span class="news-date"><?php echo date('M j, Y', strtotime($news['created_at'])); ?></span>
                    <span class="news-author">Posted by: <?php echo htmlspecialchars($news['admin_name']); ?></span>
                </div>
                <h1 class="news-title"><?php echo htmlspecialchars($news['title']); ?></h1>
                <div class="news-text">
                    <?php echo nl2br(htmlspecialchars($news['content'])); ?>
                </div>
                <a href="index.php#news" class="btn btn-primary">Back to News</a>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
