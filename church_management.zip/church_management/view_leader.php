<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isset($_GET['id'])) {
    redirect('index.php');
}

$id = intval($_GET['id']);

$sql = "SELECT leaders.*, admins.username as admin_name FROM leaders 
        LEFT JOIN admins ON leaders.admin_id = admins.id 
        WHERE leaders.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    redirect('index.php');
}

$leader = $result->fetch_assoc();
$stmt->close();
?>

<?php include 'includes/header.php'; ?>

<main class="main-content">
    <section class="leader-detail">
        <div class="container">
            <div class="leader-content">
                <div class="leader-image">
                    <img src="assets/images/leader-placeholder.jpg" alt="<?php echo htmlspecialchars($leader['name']); ?>">
                </div>
                <div class="leader-info">
                    <h1 class="leader-name"><?php echo htmlspecialchars($leader['name']); ?></h1>
                    <p class="leader-position"><?php echo htmlspecialchars($leader['position']); ?></p>
                    
                    <div class="leader-description">
                        <?php echo nl2br(htmlspecialchars($leader['description'])); ?>
                    </div>
                    
                    <div class="leader-meta">
                        <span>Posted by: <?php echo htmlspecialchars($leader['admin_name']); ?></span>
                        <span><?php echo date('M j, Y', strtotime($leader['created_at'])); ?></span>
                    </div>
                    
                    <a href="index.php#leaders" class="btn btn-primary">Back to Leadership</a>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
