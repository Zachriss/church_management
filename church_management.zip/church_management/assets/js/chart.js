document.addEventListener('DOMContentLoaded', function() {
    // Attendance Chart
    const attendanceCtx = document.getElementById('attendanceChart');
    if (attendanceCtx) {
        const attendanceData = JSON.parse(attendanceCtx.getAttribute('data-attendance'));
        
        new Chart(attendanceCtx, {
            type: 'bar',
            data: {
                labels: ['Men', 'Women', 'Children', 'Total'],
                datasets: [{
                    label: 'Attendance Statistics',
                    data: [
                        attendanceData.total_men,
                        attendanceData.total_women,
                        attendanceData.total_children,
                        attendanceData.total_attendance
                    ],
                    backgroundColor: [
                        '#3498db',
                        '#e74c3c',
                        '#f1c40f',
                        '#2ecc71'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
    
    // Sacrifices Chart
    const sacrificesCtx = document.getElementById('sacrificesChart');
    if (sacrificesCtx) {
        const sacrificesData = JSON.parse(sacrificesCtx.getAttribute('data-sacrifices'));
        
        new Chart(sacrificesCtx, {
            type: 'pie',
            data: {
                labels: ['Weekly', 'Monthly'],
                datasets: [{
                    data: [sacrificesData.weekly, sacrificesData.monthly],
                    backgroundColor: [
                        '#3498db',
                        '#e74c3c'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true
            }
        });
    }
});
