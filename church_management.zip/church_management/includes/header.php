<?php
require_once 'config.php';
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AIC Zachriss management System</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/animate.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="logo">
                <img src="<?php echo BASE_URL; ?>assets/images/Logo.png" alt="Church Logo">
                <h1>AICT Zachriss management System</h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="<?php echo BASE_URL; ?>index.php">Nyumbani</a></li>
                    <li><a href="<?php echo BASE_URL; ?>index.php#news">Taarifa/Mpya</a></li>
                    <li><a href="<?php echo BASE_URL; ?>index.php#studies">Somo La wiki</a></li>
                    <li><a href="<?php echo BASE_URL; ?>index.php#projects">Miradi ya kanisa</a></li>
                    <li><a href="<?php echo BASE_URL; ?>index.php#leaders">Uongozi wa kanisa</a></li>
                    <?php if (isLoggedIn()): ?>
                        <li><a href="<?php echo BASE_URL; ?>admin/dashboard.php">Dashboard</a></li>
                        <li><a href="<?php echo BASE_URL; ?>logout.php">Toka</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo BASE_URL; ?>login.php">Admin Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            <div class="mobile-menu-btn">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </header>

    <div class="mobile-menu">
        <ul>
            <li><a href="<?php echo BASE_URL; ?>index.php">Nyumbani</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php#news">Taarifa/Mpya</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php#studies">Somo La wiki</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php#projects">Miradi ya kanisa</a></li>
            <li><a href="<?php echo BASE_URL; ?>index.php#leaders">Uongozi wa kanisa</a></li>
            <?php if (isLoggedIn()): ?>
                <li><a href="<?php echo BASE_URL; ?>admin/dashboard.php">Dashboard</a></li>
                <li><a href="<?php echo BASE_URL; ?>logout.php">Toka</a></li>
            <?php else: ?>
                <li><a href="<?php echo BASE_URL; ?>login.php">Admin Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
