<footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section about">
                    <h3>About Our Church</h3>
                    <p>We are a community of believers dedicated to serving God and spreading His word to all nations.</p>
                    <div class="contact">
                        <span><i class="fas fa-phone"></i> +255 123 456 789</span>
                        <span><i class="fas fa-envelope"></i> info@church.org</span>
                    </div>
                </div>
                <div class="footer-section links">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="<?php echo BASE_URL; ?>index.php">Nyumbani</a></li>
                        <li><a href="<?php echo BASE_URL; ?>index.php#news">matangazo</a></li>
                        <li><a href="<?php echo BASE_URL; ?>index.php#studies">masomo</a></li>
                        <li><a href="<?php echo BASE_URL; ?>index.php#projects">miradi</a></li>
                        <li><a href="<?php echo BASE_URL; ?>index.php#leaders">uongozi wa kanisa</a></li>
                    </ul>
                </div>
                <div class="footer-section contact-form">
                    <h3>Wasiliana nasi</h3>
                    <form action="#" method="post">
                        <input type="email" name="email" class="text-input contact-input" placeholder=" email yako">
                        <textarea name="message" class="text-input contact-input" placeholder="ujumbe wako"></textarea>
                        <button type="submit" class="btn btn-big">
                            <i class="fas fa-envelope"></i> Tuma
                        </button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                &copy; <?php echo date('Y'); ?> zachriss services. All Rights Reserved.
            </div>
        </div>
    </footer>

    <script src="<?php echo BASE_URL; ?>assets/js/main.js"></script>
    <script src="<?php echo BASE_URL; ?>assets/js/chart.js"></script>
    </body>
</html>
