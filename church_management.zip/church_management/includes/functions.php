<?php
require_once 'config.php';

// Function to sanitize input data
function sanitizeInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conn->real_escape_string($data);
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['admin_id']);
}

// Function to redirect
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// Function to get member count
function getMemberCount() {
    global $conn;
    $sql = "SELECT COUNT(*) as total FROM members";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'];
}

// Function to get total sacrifices
function getTotalSacrifices() {
    global $conn;
    $sql = "SELECT SUM(amount) as total FROM sacrifices";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    return $row['total'] ? $row['total'] : 0;
}

// Function to get recent news
function getRecentNews($limit = 3) {
    global $conn;
    $sql = "SELECT * FROM news ORDER BY created_at DESC LIMIT $limit";
    $result = $conn->query($sql);
    $news = [];
    while ($row = $result->fetch_assoc()) {
        $news[] = $row;
    }
    return $news;
}

// Function to get recent studies
function getRecentStudies($limit = 3) {
    global $conn;
    $sql = "SELECT * FROM studies ORDER BY study_date DESC LIMIT $limit";
    $result = $conn->query($sql);
    $studies = [];
    while ($row = $result->fetch_assoc()) {
        $studies[] = $row;
    }
    return $studies;
}

// Function to get active projects
function getActiveProjects() {
    global $conn;
    $sql = "SELECT * FROM projects WHERE status IN ('Planning', 'In Progress') ORDER BY start_date DESC";
    $result = $conn->query($sql);
    $projects = [];
    while ($row = $result->fetch_assoc()) {
        $projects[] = $row;
    }
    return $projects;
}

// Function to get leadership structure
function getLeaders() {
    global $conn;
    $sql = "SELECT * FROM leaders ORDER BY position";
    $result = $conn->query($sql);
    $leaders = [];
    while ($row = $result->fetch_assoc()) {
        $leaders[] = $row;
    }
    return $leaders;
}

// Function to get attendance summary
function getAttendanceSummary() {
    global $conn;
    $sql = "SELECT 
            SUM(men_count) as total_men, 
            SUM(women_count) as total_women, 
            SUM(children_count) as total_children,
            SUM(total_count) as total_attendance,
            COUNT(*) as total_days
            FROM attendance";
    $result = $conn->query($sql);
    return $result->fetch_assoc();
}

// Function to get approved comments
function getApprovedComments() {
    global $conn;
    $sql = "SELECT * FROM comments WHERE approved = TRUE ORDER BY created_at DESC";
    $result = $conn->query($sql);
    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }
    return $comments;
}
?>
