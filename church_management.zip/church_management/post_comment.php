<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $comment = sanitizeInput($_POST['comment']);
    
    $sql = "INSERT INTO comments (member_name, content) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $name, $comment);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Thank you for your comment! It will be reviewed before publishing.';
    } else {
        $_SESSION['error'] = 'Error submitting comment. Please try again.';
    }
    
    $stmt->close();
}

redirect('index.php#comments');
?>
