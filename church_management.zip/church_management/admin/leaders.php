<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add leader
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_leader'])) {
    $name = sanitizeInput($_POST['name']);
    $position = sanitizeInput($_POST['position']);
    $description = sanitizeInput($_POST['description']);
    $admin_id = $_SESSION['admin_id'];
    
    $sql = "INSERT INTO leaders (name, position, description, admin_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $position, $description, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Leader added successfully';
    } else {
        $_SESSION['error'] = 'Error adding leader: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('leaders.php');
}

// Delete leader
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM leaders WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Leader deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting leader: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('leaders.php');
}

// Get all leaders
$sql = "SELECT leaders.*, admins.username as admin_name FROM leaders 
        LEFT JOIN admins ON leaders.admin_id = admins.id 
        ORDER BY position";
$result = $conn->query($sql);
$leaders = [];
while ($row = $result->fetch_assoc()) {
    $leaders[] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Leadership Management</h1>
            <button class="btn btn-primary" id="addLeaderBtn">Add Leader</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="leaders-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Description</th>
                        <th>Added By</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($leaders as $leader): ?>
                    <tr>
                        <td><?php echo $leader['id']; ?></td>
                        <td><?php echo htmlspecialchars($leader['name']); ?></td>
                        <td><?php echo htmlspecialchars($leader['position']); ?></td>
                        <td><?php echo substr(htmlspecialchars($leader['description']), 0, 100); ?>...</td>
                        <td><?php echo htmlspecialchars($leader['admin_name']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($leader['created_at'])); ?></td>
                        <td>
                            <a href="edit_leader.php?id=<?php echo $leader['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="leaders.php?delete=<?php echo $leader['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this leader?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add Leader Modal -->
<div class="modal" id="addLeaderModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add Leader</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="leaders.php" method="POST">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="position">Position</label>
                    <input type="text" id="position" name="position" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_leader" class="btn btn-primary">Add Leader</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addLeaderModal');
const btn = document.getElementById('addLeaderBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
