<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add project
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_project'])) {
    $title = sanitizeInput($_POST['title']);
    $description = sanitizeInput($_POST['description']);
    $target_amount = floatval($_POST['target_amount']);
    $current_amount = floatval($_POST['current_amount']);
    $start_date = sanitizeInput($_POST['start_date']);
    $end_date = sanitizeInput($_POST['end_date']);
    $status = sanitizeInput($_POST['status']);
    $admin_id = $_SESSION['admin_id'];
    
    $sql = "INSERT INTO projects (title, description, target_amount, current_amount, start_date, end_date, status, admin_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssddsssi", $title, $description, $target_amount, $current_amount, $start_date, $end_date, $status, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Project added successfully';
    } else {
        $_SESSION['error'] = 'Error adding project: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('projects.php');
}

// Delete project
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM projects WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Project deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting project: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('projects.php');
}

// Get all projects
$sql = "SELECT projects.*, admins.username as admin_name FROM projects 
        LEFT JOIN admins ON projects.admin_id = admins.id 
        ORDER BY start_date DESC";
$result = $conn->query($sql);
$projects = [];
while ($row = $result->fetch_assoc()) {
    $projects[] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Projects Management</h1>
            <button class="btn btn-primary" id="addProjectBtn">Add Project</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="projects-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Target Amount</th>
                        <th>Current Amount</th>
                        <th>Progress</th>
                        <th>Status</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Added By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects as $project): ?>
                    <tr>
                        <td><?php echo $project['id']; ?></td>
                        <td><?php echo htmlspecialchars($project['title']); ?></td>
                        <td><?php echo substr(htmlspecialchars($project['description']), 0, 50); ?>...</td>
                        <td><?php echo number_format($project['target_amount'], 2); ?> TZS</td>
                        <td><?php echo number_format($project['current_amount'], 2); ?> TZS</td>
                        <td>
                            <div class="progress-bar">
                                <div class="progress" style="width: <?php echo ($project['current_amount'] / $project['target_amount']) * 100; ?>%"></div>
                            </div>
                            <?php echo number_format(($project['current_amount'] / $project['target_amount']) * 100, 2); ?>%
                        </td>
                        <td>
                            <span class="status-badge <?php echo strtolower($project['status']); ?>">
                                <?php echo $project['status']; ?>
                            </span>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($project['start_date'])); ?></td>
                        <td><?php echo date('M j, Y', strtotime($project['end_date'])); ?></td>
                        <td><?php echo htmlspecialchars($project['admin_name']); ?></td>
                        <td>
                            <a href="edit_project.php?id=<?php echo $project['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="projects.php?delete=<?php echo $project['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this project?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add Project Modal -->
<div class="modal" id="addProjectModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add Project</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="projects.php" method="POST">
                <div class="form-group">
                    <label for="title">Project Title</label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="5" required></textarea>
                </div>
                <div class="form-group">
                    <label for="target_amount">Target Amount (TZS)</label>
                    <input type="number" id="target_amount" name="target_amount" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="current_amount">Current Amount (TZS)</label>
                    <input type="number" id="current_amount" name="current_amount" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" required>
                </div>
                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date">
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="Planning">Mpango</option>
                        <option value="In Progress">unaendelea</option>
                        <option value="Completed">umekamilika</option>
                        <option value="On Hold">On Hold</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_project" class="btn btn-primary">Add Project</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addProjectModal');
const btn = document.getElementById('addProjectBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
