<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Approve comment
if (isset($_GET['approve'])) {
    $id = intval($_GET['approve']);
    
    $sql = "UPDATE comments SET approved = TRUE WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Comment approved successfully';
    } else {
        $_SESSION['error'] = 'Error approving comment: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('comments.php');
}

// Delete comment
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM comments WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Comment deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting comment: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('comments.php');
}

// Get all comments
$sql = "SELECT * FROM comments ORDER BY created_at DESC";
$result = $conn->query($sql);
$comments = [];
while ($row = $result->fetch_assoc()) {
    $comments[] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Comments Management</h1>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="comments-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Comment</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($comments as $comment): ?>
                    <tr>
                        <td><?php echo $comment['id']; ?></td>
                        <td><?php echo htmlspecialchars($comment['member_name']); ?></td>
                        <td><?php echo substr(htmlspecialchars($comment['content']), 0, 100); ?>...</td>
                        <td>
                            <?php if ($comment['approved']): ?>
                            <span class="status-badge approved">Approved</span>
                            <?php else: ?>
                            <span class="status-badge pending">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($comment['created_at'])); ?></td>
                        <td>
                            <?php if (!$comment['approved']): ?>
                            <a href="comments.php?approve=<?php echo $comment['id']; ?>" class="btn btn-small btn-approve">Approve</a>
                            <?php endif; ?>
                            <a href="comments.php?delete=<?php echo $comment['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this comment?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?>
