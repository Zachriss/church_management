<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add sacrifice
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_sacrifice'])) {
    $amount = floatval($_POST['amount']);
    $week_month = sanitizeInput($_POST['week_month']);
    $period = sanitizeInput($_POST['period']);
    $admin_id = $_SESSION['admin_id'];
    
    $sql = "INSERT INTO sacrifices (amount, week_month, period, admin_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("dssi", $amount, $week_month, $period, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Sacrifice recorded successfully';
    } else {
        $_SESSION['error'] = 'Error recording sacrifice: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('sacrifices.php');
}

// Delete sacrifice
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM sacrifices WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Sacrifice deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting sacrifice: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('sacrifices.php');
}

// Get all sacrifices
$sql = "SELECT sacrifices.*, admins.username as admin_name FROM sacrifices 
        LEFT JOIN admins ON sacrifices.admin_id = admins.id 
        ORDER BY created_at DESC";
$result = $conn->query($sql);
$sacrifices = [];
while ($row = $result->fetch_assoc()) {
    $sacrifices[] = $row;
}

// Calculate totals
$weeklyTotal = 0;
$monthlyTotal = 0;
$overallTotal = 0;

foreach ($sacrifices as $sacrifice) {
    if ($sacrifice['week_month'] === 'Week') {
        $weeklyTotal += $sacrifice['amount'];
    } else {
        $monthlyTotal += $sacrifice['amount'];
    }
    $overallTotal += $sacrifice['amount'];
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Sacrifices Management</h1>
            <button class="btn btn-primary" id="addSacrificeBtn">Record Sacrifice</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="sacrifices-summary">
            <div class="summary-card">
                <h3>Weekly Total</h3>
                <p><?php echo number_format($weeklyTotal, 2); ?> TZS</p>
            </div>
            <div class="summary-card">
                <h3>Monthly Total</h3>
                <p><?php echo number_format($monthlyTotal, 2); ?> TZS</p>
            </div>
            <div class="summary-card">
                <h3>Overall Total</h3>
                <p><?php echo number_format($overallTotal, 2); ?> TZS</p>
            </div>
        </div>
        
        <div class="sacrifices-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Amount</th>
                        <th>Type</th>
                        <th>Period</th>
                        <th>Recorded By</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sacrifices as $sacrifice): ?>
                    <tr>
                        <td><?php echo $sacrifice['id']; ?></td>
                        <td><?php echo number_format($sacrifice['amount'], 2); ?> TZS</td>
                        <td><?php echo $sacrifice['week_month']; ?></td>
                        <td><?php echo htmlspecialchars($sacrifice['period']); ?></td>
                        <td><?php echo htmlspecialchars($sacrifice['admin_name']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($sacrifice['created_at'])); ?></td>
                        <td>
                            <a href="edit_sacrifice.php?id=<?php echo $sacrifice['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="sacrifices.php?delete=<?php echo $sacrifice['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this sacrifice?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add Sacrifice Modal -->
<div class="modal" id="addSacrificeModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Record Sacrifice</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="sacrifices.php" method="POST">
                <div class="form-group">
                    <label for="amount">Amount (TZS)</label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="week_month">Type</label>
                    <select id="week_month" name="week_month" required>
                        <option value="Week">Weekly</option>
                        <option value="Month">Monthly</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="period">Period (e.g., Week 1 or June 2023)</label>
                    <input type="text" id="period" name="period" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_sacrifice" class="btn btn-primary">Record Sacrifice</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addSacrificeModal');
const btn = document.getElementById('addSacrificeBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
