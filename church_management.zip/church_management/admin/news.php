<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add news
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_news'])) {
    $title = sanitizeInput($_POST['title']);
    $content = sanitizeInput($_POST['content']);
    $admin_id = $_SESSION['admin_id'];
    
    $sql = "INSERT INTO news (title, content, admin_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $title, $content, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'News added successfully';
    } else {
        $_SESSION['error'] = 'Error adding news: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('news.php');
}

// Delete news
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM news WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'News deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting news: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('news.php');
}

// Get all news
$sql = "SELECT news.*, admins.username as admin_name FROM news 
        LEFT JOIN admins ON news.admin_id = admins.id 
        ORDER BY created_at DESC";
$result = $conn->query($sql);
$news = [];
while ($row = $result->fetch_assoc()) {
    $news[] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>News Management</h1>
            <button class="btn btn-primary" id="addNewsBtn">Add News</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="news-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Content</th>
                        <th>Author</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($news as $item): ?>
                    <tr>
                        <td><?php echo $item['id']; ?></td>
                        <td><?php echo htmlspecialchars($item['title']); ?></td>
                        <td><?php echo substr(htmlspecialchars($item['content']), 0, 100); ?>...</td>
                        <td><?php echo htmlspecialchars($item['admin_name']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($item['created_at'])); ?></td>
                        <td>
                            <a href="edit_news.php?id=<?php echo $item['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="news.php?delete=<?php echo $item['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this news?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add News Modal -->
<div class="modal" id="addNewsModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add News</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="news.php" method="POST">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div class="form-group">
                    <label for="content">Content</label>
                    <textarea id="content" name="content" rows="10" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_news" class="btn btn-primary">Add News</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addNewsModal');
const btn = document.getElementById('addNewsBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
