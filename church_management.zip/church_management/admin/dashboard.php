<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

$memberCount = getMemberCount();
$sacrificesTotal = getTotalSacrifices();
$attendanceSummary = getAttendanceSummary();
$recentNews = getRecentNews(5);
//$recentSacrifices = getRecentSacrifices(5);
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Dashboard</h1>
            <p>Karibu sana !!, <?php echo $_SESSION['admin_full_name']; ?></p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $memberCount; ?></h3>
                    <p>Jumla ya waumini</p>
                </div>
                <a href="members.php" class="stat-link">Angalia Wote</a>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-pray"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($sacrificesTotal, 2); ?> TZS</h3>
                    <p>Jumla ya Matoleo</p>
                </div>
                <a href="sacrifices.php" class="stat-link">Angalia Yote</a>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-church"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $attendanceSummary['total_attendance']; ?></h3>
                    <p>Jumla ya mahudhurio</p>
                </div>
                <a href="attendance.php" class="stat-link">Angalia yote</a>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-newspaper"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo count($recentNews); ?></h3>
                    <p>Matangazo</p>
                </div>
                <a href="news.php" class="stat-link">Angalia yote</a>
            </div>
        </div>
        
        <div class="dashboard-sections">
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>Matangazo Mapya</h2>
                    <a href="news.php" class="btn btn-secondary">Angalia yote</a>
                </div>
                <div class="news-list">
                    <?php foreach ($recentNews as $news): ?>
                    <div class="news-item">
                        <h3><?php echo htmlspecialchars($news['title']); ?></h3>
                        <p><?php echo substr(htmlspecialchars($news['content']), 0, 100); ?>...</p>
                        <div class="news-meta">
                            <span><?php echo date('M j, Y', strtotime($news['created_at'])); ?></span>
                            <a href="edit_news.php?id=<?php echo $news['id']; ?>" class="btn btn-small">Edit</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="dashboard-section">
                <div class="section-header">
                    <h2>Matoleo/sadaka</h2>
                    <a href="sacrifices.php" class="btn btn-secondary">Angalia Yote</a>
                </div>
                <div class="sacrifices-list">
                    <?php foreach ($recentSacrifices as $sacrifice): ?>
                    <div class="sacrifice-item">
                        <div class="sacrifice-amount">
                            <?php echo number_format($sacrifice['amount'], 2); ?> TZS
                        </div>
                        <div class="sacrifice-info">
                            <h3><?php echo htmlspecialchars($sacrifice['period']); ?></h3>
                            <p><?php echo ucfirst($sacrifice['week_month']); ?></p>
                        </div>
                        <div class="sacrifice-date">
                            <?php echo date('M j, Y', strtotime($sacrifice['created_at'])); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>
</div>

<?php include '../includes/footer.php'; ?>
