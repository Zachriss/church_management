<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add attendance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_attendance'])) {
    $attendance_date = sanitizeInput($_POST['attendance_date']);
    $men_count = intval($_POST['men_count']);
    $women_count = intval($_POST['women_count']);
    $children_count = intval($_POST['children_count']);
    $admin_id = $_SESSION['admin_id'];
    
    $sql = "INSERT INTO attendance (attendance_date, men_count, women_count, children_count, admin_id) 
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siiii", $attendance_date, $men_count, $women_count, $children_count, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Attendance recorded successfully';
    } else {
        $_SESSION['error'] = 'Error recording attendance: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('attendance.php');
}

// Delete attendance
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM attendance WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Attendance record deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting attendance record: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('attendance.php');
}

// Get all attendance records
$sql = "SELECT attendance.*, admins.username as admin_name FROM attendance 
        LEFT JOIN admins ON attendance.admin_id = admins.id 
        ORDER BY attendance_date DESC";
$result = $conn->query($sql);
$attendance = [];
while ($row = $result->fetch_assoc()) {
    $attendance[] = $row;
}

// Calculate totals
$totalAttendance = getAttendanceSummary();
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>

    
    
    <button class="btn btn-primary" onclick="window.print()">Print Attendance</button>
    <main class="admin-content">
        <div class="admin-header">
            <h1>Attendance Management</h1>
            <button class="btn btn-primary" id="addAttendanceBtn">Record Attendance</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="attendance-summary">
            <div class="summary-card">
                <h3>Total Men</h3>
                <p><?php echo $totalAttendance['total_men']; ?></p>
            </div>
            <div class="summary-card">
                <h3>Total Women</h3>
                <p><?php echo $totalAttendance['total_women']; ?></p>
            </div>
            <div class="summary-card">
                <h3>Total Children</h3>
                <p><?php echo $totalAttendance['total_children']; ?></p>
            </div>
            <div class="summary-card">
                <h3>Total Attendance</h3>
                <p><?php echo $totalAttendance['total_attendance']; ?></p>
            </div>
            <div class="summary-card">
                <h3>Total Services</h3>
                <p><?php echo $totalAttendance['total_days']; ?></p>
            </div>
        </div>
        
        <div class="attendance-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Date</th>
                        <th>Men</th>
                        <th>Women</th>
                        <th>Children</th>
                        <th>Total</th>
                        <th>Recorded By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance as $record): ?>
                    <tr>
                        <td><?php echo $record['id']; ?></td>
                        <td><?php echo date('M j, Y', strtotime($record['attendance_date'])); ?></td>
                        <td><?php echo $record['men_count']; ?></td>
                        <td><?php echo $record['women_count']; ?></td>
                        <td><?php echo $record['children_count']; ?></td>
                        <td><?php echo $record['total_count']; ?></td>
                        <td><?php echo htmlspecialchars($record['admin_name']); ?></td>
                        <td>
                            <a href="edit_attendance.php?id=<?php echo $record['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="attendance.php?delete=<?php echo $record['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this attendance record?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add Attendance Modal -->
<div class="modal" id="addAttendanceModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Record Attendance</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="attendance.php" method="POST">
                <div class="form-group">
                    <label for="attendance_date">Date</label>
                    <input type="date" id="attendance_date" name="attendance_date" required>
                </div>
                <div class="form-group">
                    <label for="men_count">Men Count</label>
                    <input type="number" id="men_count" name="men_count" min="0" required>
                </div>
                <div class="form-group">
                    <label for="women_count">Women Count</label>
                    <input type="number" id="women_count" name="women_count" min="0" required>
                </div>
                <div class="form-group">
                    <label for="children_count">Children Count</label>
                    <input type="number" id="children_count" name="children_count" min="0" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_attendance" class="btn btn-primary">Record Attendance</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addAttendanceModal');
const btn = document.getElementById('addAttendanceBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
