<div class="admin-sidebar">
    <div class="sidebar-header">
        <h3>Admin Panel</h3>
    </div>
    <ul class="sidebar-menu">
        <li class="active">
            <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        </li>
        <li>
            <a href="members.php"><i class="fas fa-users"></i> Waumini</a>
        </li>
        <li>
            <a href="news.php"><i class="fas fa-newspaper"></i>Taarifa Mpya</a>
        </li>
        <li>
            <a href="sacrifices.php"><i class="fas fa-pray"></i> Matoleo</a>
        </li>
        <li>
            <a href="leaders.php"><i class="fas fa-user-tie"></i> Uongozi Wa Kanisa</a>
        </li>
        <li>
            <a href="projects.php"><i class="fas fa-project-diagram"></i> Miradi Ya Kanisa</a>
        </li>
        <li>
            <a href="studies.php"><i class="fas fa-bible"></i> Somo la wiki</a>
        </li>
        <li>
            <a href="attendance.php"><i class="fas fa-clipboard-list"></i> Mahudhurio</a>
        </li>
        <li>
            <a href="comments.php"><i class="fas fa-comments"></i> Maoni</a>
        </li>
        <li>
            <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Toka</a>
        </li>
    </ul>
</div>
