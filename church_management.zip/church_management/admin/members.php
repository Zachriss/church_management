<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add new member
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
    $full_name = sanitizeInput($_POST['full_name']);
    $phone = sanitizeInput($_POST['phone']);
    $email = sanitizeInput($_POST['email']);
    $address = sanitizeInput($_POST['address']);
    $gender = sanitizeInput($_POST['gender']);
    $member_since = sanitizeInput($_POST['member_since']);
    
    $sql = "INSERT INTO members (full_name, phone, email, address, gender, member_since) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $full_name, $phone, $email, $address, $gender, $member_since);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Member added successfully';
    } else {
        $_SESSION['error'] = 'Error adding member: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('members.php');
}

// Delete member
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM members WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Member deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting member: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('members.php');
}

// Get all members
$sql = "SELECT * FROM members ORDER BY full_name";
$result = $conn->query($sql);
$members = [];
while ($row = $result->fetch_assoc()) {
    $members[] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Members Management</h1>
            <button class="btn btn-primary" id="addMemberBtn">Add New Member</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="members-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Member Since</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $member): ?>
                    <tr>
                        <td><?php echo $member['id']; ?></td>
                        <td><?php echo htmlspecialchars($member['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($member['phone']); ?></td>
                        <td><?php echo htmlspecialchars($member['email']); ?></td>
                        <td><?php echo htmlspecialchars($member['gender']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($member['member_since'])); ?></td>
                        <td>
                            <a href="edit_member.php?id=<?php echo $member['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="members.php?delete=<?php echo $member['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this member?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add Member Modal -->
<div class="modal" id="addMemberModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add New Member</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="members.php" method="POST">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="text" id="phone" name="phone">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email">
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address"></textarea>
                </div>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="member_since">Member Since</label>
                    <input type="date" id="member_since" name="member_since" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_member" class="btn btn-primary">Add Member</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addMemberModal');
const btn = document.getElementById('addMemberBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
