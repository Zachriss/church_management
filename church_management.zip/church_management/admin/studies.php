<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}

// Add study
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_study'])) {
    $title = sanitizeInput($_POST['title']);
    $scripture = sanitizeInput($_POST['scripture']);
    $content = sanitizeInput($_POST['content']);
    $study_date = sanitizeInput($_POST['study_date']);
    $admin_id = $_SESSION['admin_id'];
    
    $sql = "INSERT INTO studies (title, scripture, content, study_date, admin_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $title, $scripture, $content, $study_date, $admin_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Bible study added successfully';
    } else {
        $_SESSION['error'] = 'Error adding bible study: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('studies.php');
}

// Delete study
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    
    $sql = "DELETE FROM studies WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = 'Bible study deleted successfully';
    } else {
        $_SESSION['error'] = 'Error deleting bible study: ' . $stmt->error;
    }
    
    $stmt->close();
    redirect('studies.php');
}

// Get all studies
$sql = "SELECT studies.*, admins.username as admin_name FROM studies 
        LEFT JOIN admins ON studies.admin_id = admins.id 
        ORDER BY study_date DESC";
$result = $conn->query($sql);
$studies = [];
while ($row = $result->fetch_assoc()) {
    $studies[] = $row;
}
?>

<?php include '../includes/header.php'; ?>

<div class="admin-container">
    <?php include 'sidebar.php'; ?>
    
    <main class="admin-content">
        <div class="admin-header">
            <h1>Bible Studies Management</h1>
            <button class="btn btn-primary" id="addStudyBtn">Add Study</button>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>
        
        <div class="studies-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Scripture</th>
                        <th>Content</th>
                        <th>Study Date</th>
                        <th>Added By</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($studies as $study): ?>
                    <tr>
                        <td><?php echo $study['id']; ?></td>
                        <td><?php echo htmlspecialchars($study['title']); ?></td>
                        <td><?php echo htmlspecialchars($study['scripture']); ?></td>
                        <td><?php echo substr(htmlspecialchars($study['content']), 0, 100); ?>...</td>
                        <td><?php echo date('M j, Y', strtotime($study['study_date'])); ?></td>
                        <td><?php echo htmlspecialchars($study['admin_name']); ?></td>
                        <td><?php echo date('M j, Y', strtotime($study['created_at'])); ?></td>
                        <td>
                            <a href="edit_study.php?id=<?php echo $study['id']; ?>" class="btn btn-small btn-edit">Edit</a>
                            <a href="studies.php?delete=<?php echo $study['id']; ?>" class="btn btn-small btn-delete" onclick="return confirm('Are you sure you want to delete this bible study?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<!-- Add Study Modal -->
<div class="modal" id="addStudyModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add Bible Study</h2>
            <span class="close-modal">&times;</span>
        </div>
        <div class="modal-body">
            <form action="studies.php" method="POST">
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div class="form-group">
                    <label for="scripture">Scripture Reference</label>
                    <input type="text" id="scripture" name="scripture">
                </div>
                <div class="form-group">
                    <label for="study_date">Study Date</label>
                    <input type="date" id="study_date" name="study_date" required>
                </div>
                <div class="form-group">
                    <label for="content">Content</label>
                    <textarea id="content" name="content" rows="15" required></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" name="add_study" class="btn btn-primary">Add Study</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script>
// Modal functionality
const modal = document.getElementById('addStudyModal');
const btn = document.getElementById('addStudyBtn');
const span = document.getElementsByClassName('close-modal')[0];

btn.onclick = function() {
    modal.style.display = 'block';
}

span.onclick = function() {
    modal.style.display = 'none';
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>
