<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isset($_GET['id'])) {
    redirect('index.php');
}

$id = intval($_GET['id']);

$sql = "SELECT studies.*, admins.username as admin_name FROM studies 
        LEFT JOIN admins ON studies.admin_id = admins.id 
        WHERE studies.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    redirect('index.php');
}

$study = $result->fetch_assoc();
$stmt->close();
?>

<?php include 'includes/header.php'; ?>

<main class="main-content">
    <section class="study-detail">
        <div class="container">
            <div class="study-content">
                <div class="study-meta">
                    <span class="study-date"><?php echo date('M j, Y', strtotime($study['study_date'])); ?></span>
                    <span class="study-author">Posted by: <?php echo htmlspecialchars($study['admin_name']); ?></span>
                </div>
                <h1 class="study-title"><?php echo htmlspecialchars($study['title']); ?></h1>
                <?php if ($study['scripture']): ?>
                <div class="study-scripture">
                    <p><strong>Scripture:</strong> <?php echo htmlspecialchars($study['scripture']); ?></p>
                </div>
                <?php endif; ?>
                <div class="study-text">
                    <?php echo nl2br(htmlspecialchars($study['content'])); ?>
                </div>
                <a href="index.php#studies" class="btn btn-primary">Back to Studies</a>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>
