<?php
require_once 'includes/header.php';
?>

<main class="main-content">
    <section class="hero-section">
        <div class="container">
            <div class="hero-content">
                <h2 class="animated fadeInDown">Karibu Sana Kanisani Kwetu</h2>
                <p class="animated fadeInUp delay-1">Growing in faith, serving in love</p>
                <a href="#about" class="btn btn-primary animated fadeInUp delay-2">kwa maelezo zaidi</a>
            </div>
        </div>
    </section>

    <section class="stats-section">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-card animated fadeIn delay-1">
                    <i class="fas fa-users"></i>
                    <h3><?php echo getMemberCount(); ?></h3>
                    <p><b>Waumini</b></p>
                </div>
                <div class="stat-card animated fadeIn delay-2">
                    <i class="fas fa-pray"></i>
                    <h3><?php echo getTotalSacrifices(); ?> TZS</h3>
                    <p><b>Jumla ya matoleo</b></p>
                </div>
                <div class="stat-card animated fadeIn delay-3">
                    <i class="fas fa-church"></i>
                    <h3><?php $attendance = getAttendanceSummary(); echo $attendance['total_attendance']; ?></h3>
                    <p><b>Jumla ya Mahudhurio</b></p>
                </div>
                <div class="stat-card animated fadeIn delay-4">
                    <i class="fas fa-hammer"></i>
                    <h3><?php echo count(getActiveProjects()); ?></h3>
                    <p><b>Miradi inayoendelea</b></p>
                </div>
            </div>
        </div>
    </section>

    <section id="news" class="news-section">
        <div class="container">
            <h2 class="section-title">Matangazo Mapya</h2>
            <div class="news-grid">
                <?php foreach (getRecentNews() as $news): ?>
                <div class="news-card">
                    <div class="news-image">
                        <img src="<?php echo BASE_URL; ?>assets/images/news-placeholder.jpg" alt="News Image">
                    </div>
                    <div class="news-content">
                        <h3><?php echo htmlspecialchars($news['title']); ?></h3>
                        <p><?php echo substr(htmlspecialchars($news['content']), 0, 150); ?>...</p>
                        <a href="view_news.php?id=<?php echo $news['id']; ?>" class="btn btn-secondary">Angalia zaidi</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="text-center">
                <a href="#" class="btn btn-primary">Angalia matangazo</a>
            </div>
        </div>
    </section>

    <section id="studies" class="studies-section">
        <div class="container">
            <h2 class="section-title">Masomo ya Kila wiki</h2>
            <div class="studies-grid">
                <?php foreach (getRecentStudies() as $study): ?>
                <div class="study-card">
                    <div class="study-date">
                        <span><?php echo date('d', strtotime($study['study_date'])); ?></span>
                        <span><?php echo date('M', strtotime($study['study_date'])); ?></span>
                    </div>
                    <div class="study-content">
                        <h3><?php echo htmlspecialchars($study['title']); ?></h3>
                        <p class="scripture"><?php echo htmlspecialchars($study['scripture']); ?></p>
                        <p><?php echo substr(htmlspecialchars($study['content']), 0, 200); ?>...</p>
                        <a href="view_study.php?id=<?php echo $study['id']; ?>" class="btn btn-secondary">Soma zaidi</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section id="projects" class="projects-section">
        <div class="container">
            <h2 class="section-title">Miradi Ya Kanisa</h2>
            <div class="projects-grid">
                <?php foreach (getActiveProjects() as $project): ?>
                <div class="project-card">
                    <div class="project-image">
                        <img src="<?php echo BASE_URL; ?>assets/images/project-placeholder.jpg" alt="Project Image">
                        <div class="project-status <?php echo strtolower(str_replace(' ', '-', $project['status'])); ?>">
                            <?php echo $project['status']; ?>
                        </div>
                    </div>
                    <div class="project-content">
                        <h3><?php echo htmlspecialchars($project['title']); ?></h3>
                        <p><?php echo substr(htmlspecialchars($project['description']), 0, 150); ?>...</p>
                        <div class="project-progress">
                            <div class="progress-bar">
                                <div class="progress" style="width: <?php echo ($project['current_amount'] / $project['target_amount']) * 100; ?>%"></div>
                            </div>
                            <div class="progress-text">
                                <?php echo number_format(($project['current_amount'] / $project['target_amount']) * 100, 2); ?>% Funded
                            </div>
                        </div>
                        <a href="view_project.php?id=<?php echo $project['id']; ?>" class="btn btn-secondary">Angalia Taarifa</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section id="leaders" class="leaders-section">
        <div class="container">
            <h2 class="section-title">Uongozi wa kanisa</h2>
            <div class="leaders-grid">
                <?php foreach (getLeaders() as $leader): ?>
                <div class="leader-card">
                    <div class="leader-image">
                        <img src="<?php echo BASE_URL; ?>assets/images/leader-placeholder.jpg" alt="Leader Image">
                    </div>
                    <div class="leader-content">
                        <h3><?php echo htmlspecialchars($leader['name']); ?></h3>
                        <p class="position"><?php echo htmlspecialchars($leader['position']); ?></p>
                        <p><?php echo substr(htmlspecialchars($leader['description']), 0, 100); ?>...</p>
                        <a href="view_leader.php?id=<?php echo $leader['id']; ?>" class="btn btn-secondary">View Profile</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="comments-section">
        <div class="container">
            <h2 class="section-title">Maoni Ya washiriki</h2>
            <div class="comments-container">
                <?php foreach (getApprovedComments() as $comment): ?>
                <div class="comment-card">
                    <div class="comment-header">
                        <h4><?php echo htmlspecialchars($comment['member_name']); ?></h4>
                        <span class="comment-date"><?php echo date('M j, Y', strtotime($comment['created_at'])); ?></span>
                    </div>
                    <div class="comment-content">
                        <p><?php echo htmlspecialchars($comment['content']); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="comment-form">
                <h3>Andika Maoni yako hapa</h3>
                <form action="post_comment.php" method="POST">
                    <div class="form-group">
                        <input type="text" name="name" placeholder="jina lako" required>
                    </div>
                    <div class="form-group">
                        <textarea name="comment" placeholder="maoni yako" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Tuma maoni</button>
                </form>
            </div>
        </div>
    </section>
</main>

<?php
require_once 'includes/footer.php';
?>
